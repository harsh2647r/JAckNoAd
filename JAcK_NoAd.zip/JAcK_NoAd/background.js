{
  "manifest_version": 3,
  "name": "Simple Ad Blocker",
  "version": "1.0",
  "description": "Blocks ads on websites",
  "permissions": ["webRequest", "webRequestBlocking", "declarativeNetRequest", "tabs"],
  "host_permissions": ["<all_urls>"],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html"
  }
}
