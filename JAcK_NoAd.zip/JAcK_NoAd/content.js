document.addEventListener("DOMContentLoaded", function () {
  const adSelectors = ["iframe", ".ad", ".ads", ".sponsored"];
  adSelectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((ad) => ad.remove());
  });
});
